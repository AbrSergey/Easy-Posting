--name Updated the name of this post
--introduction You know how this post was created automatically? It's quite cool

# Title -1

This is the title of my blog-post

# Text

Here i could write some text about something I care about.
<a href="/test/posts/i-like-pancakes/">Click here!!</a>
Above me is a link that you can click on, and this link works also <a href="#hmm">Click for a list</a>.
